# -*- coding: utf-8 -*-
{
    'name': "change menui name",
    'summary': """    """,
    'description': """   """,
    'author': "Abd El-hamed Saad",
    'website': "http://www.MyCompany.co",
    'category': 'Uncategorized',
    'version': '0.16',
    'license': "AGPL-3",
    'application': True,
    'auto_install': False,
    'depends': ['base', 'sale', 'sale_management', 'stock','sale_stock',],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
    ],
}
