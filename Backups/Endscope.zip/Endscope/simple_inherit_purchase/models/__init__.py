# -*- coding: utf-8 -*-

from . import simple_inherit_purchase