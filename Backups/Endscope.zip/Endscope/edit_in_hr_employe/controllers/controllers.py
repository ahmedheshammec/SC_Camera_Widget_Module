# -*- coding: utf-8 -*-
# from odoo import http


# class EditInHrEmploye(http.Controller):
#     @http.route('/edit_in_hr_employe/edit_in_hr_employe/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/edit_in_hr_employe/edit_in_hr_employe/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('edit_in_hr_employe.listing', {
#             'root': '/edit_in_hr_employe/edit_in_hr_employe',
#             'objects': http.request.env['edit_in_hr_employe.edit_in_hr_employe'].search([]),
#         })

#     @http.route('/edit_in_hr_employe/edit_in_hr_employe/objects/<model("edit_in_hr_employe.edit_in_hr_employe"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('edit_in_hr_employe.object', {
#             'object': obj
#         })
